import React, { useState, useEffect, useRef } from 'react';
import { Menu, PanelRight } from 'lucide-react';
import LeftSidebar from './components/LeftSidebar';
import RightSidebar from './components/RightSidebar';
import WelcomeScreen from './components/WelcomeScreen';
import MessageBubble from './components/MessageBubble';
import InputArea from './components/InputArea';
import { sendMessageToDex } from './services/geminiService';
import { Message, Sender } from './types';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Layout state
  const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState(false);
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (text: string) => {
    const newUserMessage: Message = {
      id: Date.now().toString(),
      sender: Sender.User,
      text,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, newUserMessage]);
    setIsLoading(true);

    // Mocking specific memory/context triggers for visual demonstration
    let responseContext: Message['context'] = undefined;
    if (text.toLowerCase().includes('remember') || text.toLowerCase().includes('note')) {
        responseContext = { type: 'note_saved', content: 'Saved to your notes' };
    } else if (text.toLowerCase().includes('remind')) {
        responseContext = { type: 'reminder', content: 'I\'ll remind you on Jan 30 at 9 AM via WhatsApp' };
    } else if (text.toLowerCase().includes('project') || text.toLowerCase().includes('alpha')) {
        responseContext = { type: 'memory', content: 'From our conversation on Jan 15...' };
    }

    const aiResponseText = await sendMessageToDex(text);

    const newAiMessage: Message = {
      id: (Date.now() + 1).toString(),
      sender: Sender.Dex,
      text: aiResponseText,
      timestamp: new Date(),
      context: responseContext
    };

    setMessages(prev => [...prev, newAiMessage]);
    setIsLoading(false);
  };

  const startNewChat = () => {
    setMessages([]);
    setIsLeftSidebarOpen(false); // Close sidebar on mobile when starting new chat
  };

  return (
    <div className="flex h-screen bg-dex-bg overflow-hidden text-dex-text font-sans">
      
      {/* Left Sidebar */}
      <LeftSidebar 
        isOpen={isLeftSidebarOpen} 
        onCloseMobile={() => setIsLeftSidebarOpen(false)}
        onNewChat={startNewChat}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative min-w-0">
        
        {/* Mobile/Tablet Header */}
        <header className="h-14 border-b border-[#262626] flex items-center justify-between px-4 md:hidden bg-dex-bg/80 backdrop-blur z-30 sticky top-0">
          <button onClick={() => setIsLeftSidebarOpen(!isLeftSidebarOpen)} className="text-dex-muted">
            <Menu size={24} />
          </button>
          <span className="font-bold text-lg">Dex</span>
          <button onClick={() => setIsRightPanelOpen(!isRightPanelOpen)} className="text-dex-muted">
            <PanelRight size={24} />
          </button>
        </header>

        {/* Chat Scroll Area */}
        <div className="flex-1 overflow-y-auto px-4 pt-6 group">
          <div className="max-w-[768px] mx-auto min-h-full flex flex-col">
            {messages.length === 0 ? (
              <WelcomeScreen onQuickAction={handleSendMessage} />
            ) : (
              <>
                 <div className="flex-1">
                    {messages.map((msg) => (
                        <MessageBubble key={msg.id} message={msg} />
                    ))}
                    {isLoading && (
                        <div className="flex items-center gap-2 mb-8 ml-2">
                           <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-600 to-green-400 flex items-center justify-center text-black text-xs font-bold animate-pulse">D</div>
                           <div className="flex gap-1">
                              <span className="w-1.5 h-1.5 bg-dex-muted rounded-full animate-bounce" style={{animationDelay: '0ms'}}></span>
                              <span className="w-1.5 h-1.5 bg-dex-muted rounded-full animate-bounce" style={{animationDelay: '150ms'}}></span>
                              <span className="w-1.5 h-1.5 bg-dex-muted rounded-full animate-bounce" style={{animationDelay: '300ms'}}></span>
                           </div>
                        </div>
                    )}
                 </div>
                 <div ref={messagesEndRef} />
              </>
            )}
          </div>
        </div>

        {/* Input Area (Sticky) */}
        <div className="bg-gradient-to-t from-dex-bg via-dex-bg to-transparent pb-4 pt-2 z-20">
          <InputArea onSendMessage={handleSendMessage} isLoading={isLoading} />
        </div>
      </main>

      {/* Right Sidebar (Quick Panel) */}
      <div className={`${isRightPanelOpen ? 'hidden lg:block' : 'hidden'} lg:relative fixed inset-0 z-50 lg:z-auto`}>
         <RightSidebar isOpen={isRightPanelOpen} onClose={() => setIsRightPanelOpen(false)} />
      </div>
      
      {/* Overlay for mobile right sidebar */}
      {isRightPanelOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsRightPanelOpen(false)}
        />
      )}
       {/* Overlay for mobile left sidebar */}
      {isLeftSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setIsLeftSidebarOpen(false)}
        />
      )}

    </div>
  );
};

export default App;