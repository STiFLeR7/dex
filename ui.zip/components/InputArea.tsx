import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, Paperclip, Clock, Pin, CheckCircle } from 'lucide-react';

interface InputAreaProps {
  onSendMessage: (text: string) => void;
  isLoading: boolean;
}

const InputArea: React.FC<InputAreaProps> = ({ onSendMessage, isLoading }) => {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (input.trim() && !isLoading) {
      onSendMessage(input);
      setInput('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [input]);

  const quickChips = [
    { icon: Clock, label: "Set reminder" },
    { icon: Pin, label: "Save note" },
    { icon: CheckCircle, label: "Check reminders" },
  ];

  return (
    <div className="w-full max-w-[768px] mx-auto px-4 pb-6 pt-2">
      {/* Quick Chips */}
      <div className="flex gap-2 mb-3 overflow-x-auto pb-1 scrollbar-hide">
        {quickChips.map((chip, idx) => (
          <button 
            key={idx}
            onClick={() => setInput(prev => `${chip.label} `)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-dex-surface/50 hover:bg-dex-surface text-xs font-medium text-dex-muted hover:text-white rounded-full border border-[#262626] transition-colors whitespace-nowrap"
          >
            <chip.icon size={12} />
            {chip.label}
          </button>
        ))}
      </div>

      {/* Input Bar */}
      <div className="relative flex items-end bg-[#262626] rounded-[24px] p-2 shadow-2xl border border-[#333] focus-within:border-dex-accent/50 transition-colors">
        
        {/* Left Actions */}
        <div className="flex items-center gap-1 mb-1 ml-1">
          <button className="p-2 text-dex-muted hover:text-white hover:bg-white/10 rounded-full transition-colors">
            <Paperclip size={20} />
          </button>
          <button className="p-2 text-dex-muted hover:text-white hover:bg-white/10 rounded-full transition-colors">
            <Mic size={20} />
          </button>
        </div>

        {/* Text Input */}
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Message Dex..."
          rows={1}
          className="flex-1 bg-transparent text-dex-text placeholder-dex-muted/70 px-3 py-3 max-h-[120px] resize-none focus:outline-none text-[15px]"
        />

        {/* Send Button */}
        <button 
          onClick={handleSend}
          disabled={!input.trim() || isLoading}
          className={`
            p-2.5 rounded-full mb-1 mr-1 transition-all duration-200
            ${input.trim() && !isLoading 
              ? 'bg-dex-accent text-black hover:scale-105 shadow-[0_0_15px_rgba(34,197,94,0.3)]' 
              : 'bg-[#333] text-dex-muted cursor-not-allowed'}
          `}
        >
          <Send size={18} fill={input.trim() ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="text-center mt-2">
         <p className="text-[10px] text-dex-muted opacity-50">Dex remembers context across web and WhatsApp.</p>
      </div>
    </div>
  );
};

export default InputArea;