import React from 'react';
import { Pin, Clock, Calendar, X, Link as LinkIcon, Smartphone } from 'lucide-react';
import { Note, Reminder } from '../types';

interface RightSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const MOCK_NOTES: Note[] = [
  { id: '1', title: 'Passport Number', content: 'A12345678', pinned: true, date: '2024-01-15' },
  { id: '2', title: 'Wifi Password', content: 'SuperSecret123!', pinned: true, date: '2024-01-10' },
];

const MOCK_REMINDERS: Reminder[] = [
  { id: '1', text: 'Call Mom', dueTime: 'Today, 6:00 PM', platform: 'WhatsApp' },
  { id: '2', text: 'Submit Tax Report', dueTime: 'Friday, 9:00 AM', platform: 'System' },
];

const RightSidebar: React.FC<RightSidebarProps> = ({ isOpen, onClose }) => {
  return (
    <aside className={`
      fixed inset-y-0 right-0 z-40 w-[300px] bg-[#141414] border-l border-[#262626] transform transition-transform duration-300 ease-in-out
      ${isOpen ? 'translate-x-0' : 'translate-x-full'}
      lg:relative lg:translate-x-0 lg:block flex flex-col shadow-2xl lg:shadow-none
    `}>
      <div className="p-4 border-b border-[#262626] flex items-center justify-between">
        <h2 className="font-semibold text-dex-text">Quick Access</h2>
        <button onClick={onClose} className="lg:hidden text-dex-muted hover:text-white">
          <X size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        
        {/* Today's Context */}
        <div className="bg-dex-surface/30 rounded-xl p-4 border border-[#262626]">
           <div className="flex items-center gap-2 mb-3 text-dex-accent">
              <Calendar size={16} />
              <span className="text-xs font-bold uppercase tracking-wider">Today's Context</span>
           </div>
           <div className="text-2xl font-bold text-white mb-1">Jan 28</div>
           <div className="text-sm text-dex-muted mb-3">Monday • 10:42 AM</div>
           <div className="h-px bg-[#333] mb-3"></div>
           <div className="text-xs text-dex-muted space-y-2">
              <p>• 2 meetings remaining</p>
              <p>• Gym at 5:30 PM</p>
           </div>
        </div>

        {/* Pinned Notes */}
        <div>
            <div className="flex items-center gap-2 mb-3 text-dex-muted px-1">
                <Pin size={14} />
                <span className="text-xs font-bold uppercase tracking-wider">Memory & Notes</span>
            </div>
            <div className="space-y-2">
                {MOCK_NOTES.map(note => (
                    <div key={note.id} className="bg-dex-surface p-3 rounded-lg border border-[#262626] hover:border-dex-accent/30 transition-colors group cursor-pointer">
                        <div className="flex justify-between items-start mb-1">
                            <h4 className="text-sm font-medium text-dex-text">{note.title}</h4>
                            <Pin size={12} className="text-dex-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                        <p className="text-xs text-dex-muted font-mono bg-black/30 p-1.5 rounded mt-1">{note.content}</p>
                    </div>
                ))}
            </div>
        </div>

        {/* Reminders */}
        <div>
            <div className="flex items-center gap-2 mb-3 text-dex-muted px-1">
                <Clock size={14} />
                <span className="text-xs font-bold uppercase tracking-wider">Upcoming Reminders</span>
            </div>
            <div className="space-y-2">
                {MOCK_REMINDERS.map(reminder => (
                    <div key={reminder.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-dex-surface/50 transition-colors">
                        <div className={`mt-0.5 w-4 h-4 rounded-full border-2 ${reminder.platform === 'WhatsApp' ? 'border-green-500' : 'border-gray-500'} flex items-center justify-center`}>
                           {reminder.platform === 'WhatsApp' && <div className="w-1.5 h-1.5 rounded-full bg-green-500" />}
                        </div>
                        <div>
                            <p className="text-sm text-dex-text decoration-dex-muted/50">{reminder.text}</p>
                            <p className="text-xs text-dex-accent mt-0.5">{reminder.dueTime}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>

         {/* Integrations */}
         <div className="pt-4 border-t border-[#262626]">
            <div className="flex items-center gap-2 mb-3 text-dex-muted px-1">
                <LinkIcon size={14} />
                <span className="text-xs font-bold uppercase tracking-wider">Connected</span>
            </div>
            <div className="flex gap-2">
                 <div className="bg-[#075e54]/20 text-[#25D366] px-3 py-1.5 rounded-full text-xs font-medium border border-[#25D366]/30 flex items-center gap-1.5">
                    <Smartphone size={12} /> WhatsApp
                 </div>
                 <div className="bg-[#0088cc]/20 text-[#0088cc] px-3 py-1.5 rounded-full text-xs font-medium border border-[#0088cc]/30">
                    Telegram
                 </div>
            </div>
         </div>
      </div>
    </aside>
  );
};

export default RightSidebar;