import React, { useEffect, useState } from 'react';
import { Clock, Pin, Brain, Sparkles, MessageCircle } from 'lucide-react';

interface WelcomeScreenProps {
  onQuickAction: (text: string) => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onQuickAction }) => {
  const [currentDate, setCurrentDate] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Format: "Monday, January 28, 2026 • 10:42 AM IST"
      const options: Intl.DateTimeFormatOptions = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        hour12: true,
        timeZoneName: 'short'
      };
      setCurrentDate(now.toLocaleDateString('en-US', options));
    };
    
    updateTime();
    const timer = setInterval(updateTime, 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center h-full text-center px-4 animate-fade-in">
      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-dex-surface to-dex-accent flex items-center justify-center mb-6 shadow-2xl shadow-green-900/20">
        <span className="text-4xl font-bold text-white">D</span>
      </div>
      
      <h1 className="text-3xl font-semibold text-white mb-2">Hey, I'm Dex</h1>
      <p className="text-dex-muted text-lg mb-8 max-w-md">Your memory-aware personal assistant.</p>
      
      <div className="text-sm font-medium text-dex-accent bg-dex-surface/50 px-4 py-2 rounded-full mb-12 border border-dex-surface">
        {currentDate}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl w-full">
        <button 
          onClick={() => onQuickAction("Set a reminder for tomorrow at 9 AM")}
          className="flex items-center gap-4 p-4 rounded-xl bg-dex-surface hover:bg-[#333] border border-[#333] hover:border-dex-accent/50 transition-all group text-left"
        >
          <div className="p-3 rounded-lg bg-[#1a1a1a] group-hover:text-dex-accent text-dex-muted transition-colors">
            <Clock size={20} />
          </div>
          <div>
            <div className="font-medium text-white">Set a reminder</div>
            <div className="text-xs text-dex-muted">Track time & tasks</div>
          </div>
        </button>

        <button 
           onClick={() => onQuickAction("Save this context to my notes")}
           className="flex items-center gap-4 p-4 rounded-xl bg-dex-surface hover:bg-[#333] border border-[#333] hover:border-dex-accent/50 transition-all group text-left"
        >
          <div className="p-3 rounded-lg bg-[#1a1a1a] group-hover:text-dex-accent text-dex-muted transition-colors">
            <Pin size={20} />
          </div>
          <div>
            <div className="font-medium text-white">Save a note</div>
            <div className="text-xs text-dex-muted">Pin important details</div>
          </div>
        </button>

        <button 
           onClick={() => onQuickAction("What do you remember about my project?")}
           className="flex items-center gap-4 p-4 rounded-xl bg-dex-surface hover:bg-[#333] border border-[#333] hover:border-dex-accent/50 transition-all group text-left"
        >
          <div className="p-3 rounded-lg bg-[#1a1a1a] group-hover:text-dex-accent text-dex-muted transition-colors">
            <Brain size={20} />
          </div>
          <div>
            <div className="font-medium text-white">What do you remember...</div>
            <div className="text-xs text-dex-muted">Recall past conversations</div>
          </div>
        </button>

        <button 
           onClick={() => onQuickAction("Help me brainstorm ideas for...")}
           className="flex items-center gap-4 p-4 rounded-xl bg-dex-surface hover:bg-[#333] border border-[#333] hover:border-dex-accent/50 transition-all group text-left"
        >
          <div className="p-3 rounded-lg bg-[#1a1a1a] group-hover:text-dex-accent text-dex-muted transition-colors">
            <Sparkles size={20} />
          </div>
          <div>
            <div className="font-medium text-white">Help me with...</div>
            <div className="text-xs text-dex-muted">Drafting, planning, coding</div>
          </div>
        </button>
      </div>

      <div className="mt-12 flex items-center gap-2 text-dex-muted text-sm opacity-60">
        <MessageCircle size={14} className="text-green-500" />
        <span>Also available on WhatsApp</span>
      </div>
    </div>
  );
};

export default WelcomeScreen;