import React from 'react';
import { Plus, Search, MessageSquare, Smartphone, Settings, User } from 'lucide-react';
import { Conversation } from '../types';

interface LeftSidebarProps {
  isOpen: boolean;
  onCloseMobile: () => void;
  onNewChat: () => void;
}

const MOCK_HISTORY: Conversation[] = [
  { id: '1', title: 'Project Alpha Planning', lastMessage: 'Let\'s review the timeline...', timestamp: new Date(), isSyncedWhatsApp: true },
  { id: '2', title: 'Grocery List', lastMessage: 'Don\'t forget milk', timestamp: new Date(Date.now() - 86400000), isSyncedWhatsApp: true },
  { id: '3', title: 'React Component Architecture', lastMessage: 'Using composition for...', timestamp: new Date(Date.now() - 172800000), isSyncedWhatsApp: false },
  { id: '4', title: 'Travel Itinerary', lastMessage: 'Flight leaves at 6 PM', timestamp: new Date(Date.now() - 400000000), isSyncedWhatsApp: false },
];

const LeftSidebar: React.FC<LeftSidebarProps> = ({ isOpen, onCloseMobile, onNewChat }) => {
  return (
    <aside className={`
      fixed inset-y-0 left-0 z-40 w-[280px] bg-dex-sidebar border-r border-[#262626] transform transition-transform duration-300 ease-in-out
      ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      md:relative md:translate-x-0 flex flex-col
    `}>
      {/* Header */}
      <div className="p-4">
        <div className="flex items-center gap-3 mb-6 px-2">
            {/* Logo Placeholder - assuming dex.png exists in a real env, using text fallback here */}
            <div className="font-bold text-2xl tracking-tighter text-white flex items-center gap-1">
                <span className="text-dex-text">Dex</span>
            </div>
        </div>

        <button 
          onClick={onNewChat}
          className="w-full flex items-center gap-2 bg-dex-surface hover:bg-[#333] text-dex-text p-3 rounded-lg border border-[#333] transition-colors group mb-4"
        >
          <div className="w-6 h-6 rounded-full bg-dex-accent/20 flex items-center justify-center text-dex-accent group-hover:bg-dex-accent group-hover:text-black transition-colors">
            <Plus size={16} />
          </div>
          <span className="font-medium text-sm">New Chat</span>
        </button>

        <div className="relative">
          <Search className="absolute left-3 top-2.5 text-dex-muted" size={16} />
          <input 
            type="text" 
            placeholder="Search conversations..." 
            className="w-full bg-[#141414] text-dex-text text-sm rounded-lg pl-9 pr-3 py-2 border border-transparent focus:border-dex-accent/50 focus:outline-none placeholder-zinc-600"
          />
        </div>
      </div>

      {/* History List */}
      <div className="flex-1 overflow-y-auto px-2 py-2 space-y-6">
        <div>
          <h3 className="text-xs font-semibold text-dex-muted uppercase tracking-wider px-4 mb-2">Today</h3>
          {MOCK_HISTORY.slice(0, 1).map(chat => (
             <HistoryItem key={chat.id} chat={chat} />
          ))}
        </div>
        
        <div>
          <h3 className="text-xs font-semibold text-dex-muted uppercase tracking-wider px-4 mb-2">Yesterday</h3>
          {MOCK_HISTORY.slice(1, 2).map(chat => (
             <HistoryItem key={chat.id} chat={chat} />
          ))}
        </div>

        <div>
          <h3 className="text-xs font-semibold text-dex-muted uppercase tracking-wider px-4 mb-2">Previous 30 Days</h3>
          {MOCK_HISTORY.slice(2).map(chat => (
             <HistoryItem key={chat.id} chat={chat} />
          ))}
        </div>
      </div>

      {/* Footer / Profile */}
      <div className="p-4 border-t border-[#262626]">
        <div className="flex items-center justify-between p-2 rounded-lg hover:bg-dex-surface cursor-pointer transition-colors group">
          <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded-full bg-[#333] flex items-center justify-center text-dex-muted">
                <User size={16} />
             </div>
             <div>
                <div className="text-sm font-medium text-dex-text">Alex Doe</div>
                <div className="text-xs text-dex-accent flex items-center gap-1">
                    <Smartphone size={10} />
                    WhatsApp Synced
                </div>
             </div>
          </div>
          <Settings size={16} className="text-dex-muted group-hover:text-dex-text" />
        </div>
      </div>
    </aside>
  );
};

const HistoryItem: React.FC<{ chat: Conversation }> = ({ chat }) => (
  <button className="w-full text-left px-4 py-3 rounded-lg hover:bg-dex-surface/50 group transition-colors relative">
    <div className="flex justify-between items-start mb-1">
        <span className="text-sm font-medium text-dex-text truncate pr-4">{chat.title}</span>
        {chat.isSyncedWhatsApp && (
            <span className="text-[10px] bg-green-900/30 text-green-500 px-1.5 py-0.5 rounded border border-green-900/50">WA</span>
        )}
    </div>
    <div className="text-xs text-dex-muted truncate">{chat.lastMessage}</div>
  </button>
);

export default LeftSidebar;